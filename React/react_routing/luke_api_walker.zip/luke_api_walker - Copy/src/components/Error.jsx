import React from "react";
import obi from "./obi.gif"

export const Error = (props) => {

    return (
        <>
            <div className="flex-col align-items-center text-center">
                <img src={obi}></img>
            </div>
        </>
    )
}